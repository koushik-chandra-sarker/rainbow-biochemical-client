"use strict";
exports.id = 197;
exports.ids = [197];
exports.modules = {

/***/ 4197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Feature_Feature)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/imgs/about-as.jpg
/* harmony default export */ const about_as = ({"src":"/_next/static/media/about-as.7e102a39.jpg","height":687,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAQEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAKBf/8QAGxAAAgIDAQAAAAAAAAAAAAAAAgMBBQAEEUL/2gAIAQEAAT8AsbuwRqoWDi6Ywcn66Wf/xAAXEQEAAwAAAAAAAAAAAAAAAAABAAMT/9oACAECAQE/AKFzGf/EABkRAQACAwAAAAAAAAAAAAAAAAEAAgMEIf/aAAgBAwEBPwDaAzWDhP/Z","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./pages/components/Feature/Feature.js




const Feature = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "text-gray-600 body-font",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " py-24 mx-auto flex flex-wrap",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tablet:w-1/2 w-full mb-10 tablet:mb-0 rounded-tablet overflow-hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "feature",
                            className: "tablet:object-cover object-contain object-center tablet:h-128 h-60 w-full",
                            src: about_as
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col flex-wrap tablet:py-6 -mb-10 tablet:w-1/2 tablet:pl-12 tablet:text-left text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-col mb-10 tablet:items-start items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex-grow",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "leading-relaxed text-base",
                                        children: "Miami Associates (BD) started its journey in the beginning of 1990 with the objective to import, supply, marketing and trading various kinds of Products & services to national & multinational company in Bangladesh. Presently Miami Associates (BD) is operating its Business with permanent setup in Dhaka, Chittagong & Cox’s Bazar and servicing the customers with ultimate satisfaction and excellence."
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-col mb-10 tablet:items-start items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex-grow",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "leading-relaxed text-base",
                                        children: "Miami Associates (BD) started its journey in the beginning of 1990 with the objective to import, supply, marketing and trading various kinds of Products & services to national & multinational company in Bangladesh. Presently Miami Associates (BD) is operating its Business with permanent setup in Dhaka, Chittagong & Cox’s Bazar and servicing the customers with ultimate satisfaction and excellence."
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-col mb-10 tablet:items-start items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex-grow",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "leading-relaxed text-base",
                                        children: "Miami Associates (BD) is the appointed agent of BASF’s Intermediates division in Bangladesh."
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-col mb-10 tablet:items-start items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex-grow",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "leading-relaxed text-base",
                                        children: "Miami Associates (BD) also has business of Hot-melt adhesive, Poultry Feed Ingredients and Doctor blade for rotogravure & flexo printing machine and also capable to supply various types’ products on demand."
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Feature_Feature = (Feature);


/***/ })

};
;