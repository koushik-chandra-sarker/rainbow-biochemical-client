"use strict";
exports.id = 474;
exports.ids = [474];
exports.modules = {

/***/ 6474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5623);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2__);



const ContactForm = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "mobile:w-8/12 w-full mx-auto mobile:flex  mt-10",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mobile:w-1/2 w-full mobile:mr-4 mobile:mx-0 mx-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            name: "firstName",
                            placeholder: "FIRST NAME",
                            className: "w-full text-sm mb-4 text-gray-400 placeholder-gray-400 pl-8 rounded-md border border-gray-300 focus:border-black outline-none bg-gray-100 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            name: "",
                            placeholder: "COMPANY NAME",
                            className: "w-full text-sm mb-4 text-gray-400 placeholder-gray-400 pl-8 rounded-md border border-gray-300 focus:border-black outline-none bg-gray-100 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            name: "subject",
                            placeholder: "SUBJECT",
                            className: "w-full text-sm mb-4 text-gray-400 placeholder-gray-400 pl-8 rounded-md border border-gray-300 global-color focus:border-black outline-none bg-gray-100 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                            type: "text",
                            name: "phone",
                            placeholder: "ADDRESS",
                            className: "w-full text-sm placeholder-gray-400 pl-8 rounded-md border border-gray-300 focus:border-black outline-none bg-gray-100 text-gray-400 pb-16 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mobile:w-1/2 w-full mobile:ml-4 mobile:mx-0 mx-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            name: "lastName",
                            placeholder: "LAST NAME",
                            className: "w-full mb-4 text-sm text-gray placeholder-gray-400 placeholder pl-8 rounded-md border border-gray-300 global-color focus:border-black outline-none bg-gray-100 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            name: "phone",
                            placeholder: "PHONE NUMBER",
                            className: "w-full mb-4 text-sm text-gray-400 placeholder-gray-400 pl-8 rounded-md border border-gray-300 global-color focus:border-black outline-none bg-gray-100 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "email",
                            name: "email",
                            placeholder: "E-MAIL ADDRESS",
                            className: "w-full mb-4 text-sm text-gray-400 placeholder-gray-400 pl-8 rounded-md border border-gray-300 global-color focus:border-black outline-none bg-gray-100 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                            type: "text",
                            name: "message",
                            placeholder: "MESSAGE",
                            className: "w-full text-sm placeholder-gray-400 pl-8 rounded-md border border-gray-300 focus:border-black outline-none bg-gray-100 text-gray-400 pb-16 py-2 px-3 leading-8 transition-colors duration-200 ease-in-out"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "pt-4 justify-end flex",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "w-32 rounded-3xl align-center items-center flex justify-center text-white bg-blue-600 py-4 text-sm",
                                children: "Send"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContactForm);


/***/ })

};
;