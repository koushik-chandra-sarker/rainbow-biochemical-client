(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,993,633,478,875,979];
exports.modules = {

/***/ 3114:
/***/ ((module) => {

// Exports
module.exports = {
	"search": "Search_search__Tx_zl",
	"search_input": "Search_search_input__46kkM",
	"show_box": "Search_show_box__7OBlw",
	"search_icon": "Search_search_icon__PG1Bp",
	"remove_icon": "Search_remove_icon__B1gqA",
	"add_icon": "Search_add_icon__b8R4M",
	"remove_close_icon": "Search_remove_close_icon__kU5eF",
	"last": "Search_last__2drx6"
};


/***/ }),

/***/ 7002:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "Header_navbar__U8dQD",
	"dropdown": "Header_dropdown__6M0Ga",
	"dropdown_icon": "Header_dropdown_icon__2racT",
	"dropdown_item": "Header_dropdown_item__7GiST",
	"right": "Header_right__4jKrY",
	"overlay": "Header_overlay__JWswp",
	"hamburger": "Header_hamburger__9Tgn7"
};


/***/ }),

/***/ 1323:
/***/ ((module) => {

// Exports
module.exports = {
	"sidebar": "Sidebar_sidebar__mnPDn",
	"item": "Sidebar_item__vn2fO",
	"sub_item": "Sidebar_sub_item__IpE4j",
	"dropdown": "Sidebar_dropdown__ygIGN",
	"dropdown_icon": "Sidebar_dropdown_icon__iIxjI",
	"open": "Sidebar_open__hf6rM",
	"dropdown_item": "Sidebar_dropdown_item__jeD2d",
	"dropdown_item_open": "Sidebar_dropdown_item_open__NOtie"
};


/***/ }),

/***/ 4394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/icon-mail.bc703af2.png","height":34,"width":34,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAaVBMVEXlFC/kFDDkFC/kFC/kFC/lFC/kFC/lFC/kFC/lFC/lFC/kFC/lFC/kFC/kFC/lFC/kFC/lFC/lFC/lFC/kFC/lFC/lFC/kFC/lFC/lFC/lFC/kFC/lFC/kFC/lFC/kFC/kFC/lFC/lFC9bClDVAAAAI3RSTlMAAAACAwYGDAwNDw89PUJDQ0lfYmJpa2tvcHJyc3N8fH2AgSgCnjoAAABFSURBVHjaBUCHEYAgDHyxQGwRIhosWPYfkgNs79xgAUlyHpJWvJ4N2D+IZs95qyLCyHUzTwH/0gEtfxDV+1IVGCJniVAAiCADwX4Oae0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/icon-phone.f22f6f53.png","height":34,"width":34,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAdVBMVEXlFTDlFC/kFC8AAADlFC/kFC/lFC/kFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/kFC/lFC/lFC/lFC/kFC/lFC/lFC/lFC/lFC/kFC/lFC/lFC/kFC/lFC/lFC/lFC/Yqf+hAAAAJ3RSTlMAAAAAAgIDBQYOGyYnLzE3OD0+QUNHSUlMVVpma2xub3Z3fH6AhI7eujnaAAAAR0lEQVR42g3GVwJAMBQEwN2IpwTRiS7K/Y/IfA2iZ6AoBpjbpaT+c4XpwVgruGbsSArgs7PerQJzb5xZewgLX9G+oFBP95Z8dtIDiib1iP8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/icon-share.a2f6076c.png","height":34,"width":34,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAclBMVEXlFC/kFC/kFC/lFC/lFC/lFC/kFC/lFC/kFC/kFC/lFC/lFC/kFC/lFC/kFC/kFC/lFC/kFC/lFC/lFC/kFC/kFC/lFC/kFC/lFC/lFC/kFC/lFC/lFC/kFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC/lFC+oVDzdAAAAJnRSTlMAAAECAwUFCw8gLD5BQ0pXWFlaYGBiZ252eHh+gYKEhYaIl5ufp0c8dyMAAABDSURBVHjaFcGHEYAgEADBexEx54wKpv5bdNxlcQ06VArPk/DrjmEei61EIkhfTkRjqqu29Ptk8yiL8dxGBFhdi0YFH3hAAzpALyWTAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2847:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo_h.2b513e48.jpg","height":227,"width":500,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAooR//8QAGhABAAMAAwAAAAAAAAAAAAAAAQIDBAARsf/aAAgBAQABPwCnVpbLQtYxjcnQRfR5/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAFRcf/aAAgBAgEBPwCYj//EABURAQEAAAAAAAAAAAAAAAAAAAAB/9oACAEDAQE/AI//2Q==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 1002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/p1.2237d04b.jpg","height":282,"width":200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAL4pP//EAB0QAAIBBAMAAAAAAAAAAAAAAAECAwAEBSIGESP/2gAIAQEAAT8AwEWetuQ5eGV7pYt39SSp7fQiv//EABoRAQABBQAAAAAAAAAAAAAAAAIBAAQRIbH/2gAIAQIBAT8AuHKZnEbB5X//xAAZEQEAAgMAAAAAAAAAAAAAAAABAAIRITH/2gAIAQMBAT8AoYHb1n//2Q==","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 1881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/p2.07fd9cd9.jpg","height":282,"width":200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApoP/xAAcEAEAAgEFAAAAAAAAAAAAAAABAgMABBESUoH/2gAIAQEAAT8ApdZbZfGcQCx4MV3Ynb3P/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k=","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/p3.70de92b4.jpg","height":282,"width":200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAKiKP//EABwQAAICAgMAAAAAAAAAAAAAAAEDESECEgAFQf/aAAgBAQABPwBTewWw5tCYMjXacRdeC45//8QAFxEAAwEAAAAAAAAAAAAAAAAAABESIf/aAAgBAgEBPwBVp//EABYRAQEBAAAAAAAAAAAAAAAAABEAAf/aAAgBAwEBPwBDL//Z","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 6855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/p4.de13285e.jpg","height":282,"width":200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAgX/2gAMAwEAAhADEAAAAL8Oh//EABsQAAICAwEAAAAAAAAAAAAAAAIDAQQAEyEy/9oACAEBAAE/ANzQrqMLpmwvS+TI5//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABkRAAIDAQAAAAAAAAAAAAAAAAECABEhMf/aAAgBAwEBPwAIovL09n//2Q==","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 2907:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_assets_icons_icon_phone_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5917);
/* harmony import */ var _public_assets_icons_icon_mail_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4394);
/* harmony import */ var _public_assets_icons_icon_share_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1549);
/* harmony import */ var _public_assets_imgs_p1_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1002);
/* harmony import */ var _public_assets_imgs_p2_jpg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1881);
/* harmony import */ var _public_assets_imgs_p3_jpg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(545);
/* harmony import */ var _public_assets_imgs_p4_jpg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6855);
/* harmony import */ var _public_assets_imgs_logo_h_jpg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2847);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3877);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_12__, swiper__WEBPACK_IMPORTED_MODULE_13__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_12__, swiper__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const Footer = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(""),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                className: "my-20"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "top tablet:w-8/12 w-11/12  mx-auto grid desktop:grid-cols-3 tablet:grid-cols-2 mobile:py-4 grid-cols-1   gap-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(""),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex items-center gap-4"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("w-18 h-18 border-2 rounded-full text-3xl p-4   flex justify-center items-center"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            src: _public_assets_icons_icon_phone_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                            alt: "Phone Icon"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-xl"),
                                        children: "FREE CONSUMER HELPLINE"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "desktop:my-8 my-3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-gray-500 text-base"),
                                children: "Whenever you wish, Any complain, suggestion or thanks for Miami Associates (BD),you can forward it to us via the Free Consumer Helpline."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(""),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex items-center gap-4"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("w-18 h-18 border-2 rounded-full text-3xl p-4 flex justify-center items-center"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            src: _public_assets_icons_icon_mail_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                            alt: "Phone Icon"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-xl"),
                                        children: "SUBSCRIBE TO E-NEWS"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "desktop:my-8 my-3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                action: "",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "relative sm:w-auto xl:mr-4 lg:mr-0 sm:mr-4 mr-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            id: "footer-field",
                                            name: "footer-field",
                                            placeholder: "Your E-mail address",
                                            className: "w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:bg-transparent focus:ring-2 focus:ring-green-600 focus:border-green-600 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "mt-5 flex-shrink-0 inline-flex tracking-widest transition-all text-gray-50 hover:text-gray-700 font-bold uppercase bg-gray-400 hover:bg-green-500 border-0 py-2 px-6 focus:outline-none rounded-badge",
                                            children: "Register"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(""),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex items-center gap-4"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("w-18 h-18 border-2 rounded-full text-3xl p-4 flex justify-center items-center"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            src: _public_assets_icons_icon_share_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                            alt: "Phone Icon"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-xl"),
                                        children: "FOLLOW US"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "my-8"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_12__.Swiper, {
                                slidesPerView: 2,
                                spaceBetween: 30,
                                navigation: true,
                                autoplay: {
                                    delay: 1000,
                                    disableOnInteraction: false,
                                    pauseOnMouseEnter: true
                                },
                                modules: [
                                    swiper__WEBPACK_IMPORTED_MODULE_13__.Autoplay,
                                    swiper__WEBPACK_IMPORTED_MODULE_13__.Navigation
                                ],
                                className: "mySwiper",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_12__.SwiperSlide, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "h-32 w-32",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                src: _public_assets_imgs_p1_jpg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                                alt: "p1",
                                                className: "w-full h-full object-contain"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_12__.SwiperSlide, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "h-32 w-32",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                src: _public_assets_imgs_p2_jpg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                                alt: "p1",
                                                className: "w-full h-full object-contain"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_12__.SwiperSlide, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "h-32 w-32",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                src: _public_assets_imgs_p3_jpg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                                alt: "p1",
                                                className: "w-full h-full object-contain"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_12__.SwiperSlide, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "h-32 w-32",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                src: _public_assets_imgs_p4_jpg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                                alt: "p1",
                                                className: "w-full h-full object-contain"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                className: "my-20"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "bottom top tablet:w-8/12 w-11/12 mx-auto ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: "flex flex-wrap gap-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                src: _public_assets_imgs_logo_h_jpg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                                alt: "Brand Logo",
                                className: "w-40 tablet:border-r-2 pr-4"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "tablet:ml-4 flex items-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-gray-500 text-base"),
                                    children: [
                                        "Biochemical has been manufacturing",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "innovative products in the field of industrial and retail."
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: "grid desktop:grid-cols-4 tablet:grid-cols-2 grid-cols-1 gap-4 mt-20",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                className: "tablet:block flex flex-col justify-center items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-base"),
                                        children: "Products"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: "my-5 w-full"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-gray-500 text-sm"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "mb-2",
                                            children: "MARKET PRODUCTS"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                className: "tablet:block flex flex-col justify-center items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-base"),
                                        children: "Biochemical"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: "my-5 w-full"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-gray-500 text-sm tablet:block flex gap-5"),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mb-2",
                                                children: "Home"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mb-2",
                                                children: "About Us"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mb-2",
                                                children: "Client"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                className: "tablet:block flex flex-col justify-center items-center tablet:text-left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-base"),
                                        children: "Contact"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: "my-5 w-full"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex flex-col",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-xs leading-6",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: " tablet:block flex flex-col justify-center items-center text-center tablet:text-left",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Ka-70/1, Progati Sharani ( 2nd & 3rd Floor), Kuril, Vatara Dhaka-1229, Bangladesh,"
                                                        }),
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Phone: "
                                                        }),
                                                        " +880 2 550 00 000 ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Email: "
                                                        }),
                                                        " demo@mail.com"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                    className: "my-2"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "mt-2 tablet:block flex flex-col justify-center items-center text-center tablet:text-left",
                                                    children: [
                                                        "528/545, S.K. Mujib Road , Dewanhut, Chittagong , Bangladesh ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Mobile: "
                                                        }),
                                                        " 01819 888045. ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Phone: "
                                                        }),
                                                        "031 2510787"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                    className: "my-2"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: " tablet:block flex flex-col justify-center items-center text-center tablet:text-left",
                                                    children: [
                                                        "Haque Tower, 3rd Floor, Alir Jahal, Cox’s Bazar ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Mobile: "
                                                        }),
                                                        "+8801847166798, +8801839564836"
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                className: "tablet:block flex flex-col justify-center items-center mt-5 tablet:mt-0",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-bold text-base"),
                                        children: "Social Media"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: "my-5 w-full"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-gray-500 text-sm tablet:block flex gap-3"),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mb-2 hover:text-indigo-500",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    href: "#",
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.FacebookFilled, {
                                                            className: "text-2xl"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Facebook"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mb-2 hover:text-pink-600",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    href: "#",
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.InstagramFilled, {
                                                            className: "text-2xl"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Instagram"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "mb-2 hover:text-blue-400",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    href: "#",
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.TwitterSquareFilled, {
                                                            className: "text-2xl"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Twitter"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "w-full flex justify-center items-center py-2  mt-20 bg-green-100",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.CopyrightOutlined, {
                        className: "mr-2"
                    }),
                    " 2021 Develop by Waysis-IT Solution"
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 433:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/layout/Header/Header.module.scss
var Header_module = __webpack_require__(7002);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: external "@react-icons/all-files/fa/FaPhoneSquareAlt"
const FaPhoneSquareAlt_namespaceObject = require("@react-icons/all-files/fa/FaPhoneSquareAlt");
;// CONCATENATED MODULE: external "@react-icons/all-files/ri/RiArrowDownSLine"
const RiArrowDownSLine_namespaceObject = require("@react-icons/all-files/ri/RiArrowDownSLine");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/imgs/logo_h.jpg
var logo_h = __webpack_require__(2847);
;// CONCATENATED MODULE: external "@react-icons/all-files/bi/BiSearch"
const BiSearch_namespaceObject = require("@react-icons/all-files/bi/BiSearch");
;// CONCATENATED MODULE: external "@react-icons/all-files/io5/IoClose"
const IoClose_namespaceObject = require("@react-icons/all-files/io5/IoClose");
// EXTERNAL MODULE: ./components/Search/Search.module.scss
var Search_module = __webpack_require__(3114);
var Search_module_default = /*#__PURE__*/__webpack_require__.n(Search_module);
;// CONCATENATED MODULE: ./components/Search/Search.js






const Search = ()=>{
    const [openSearchBox, setOpenSearchBox] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Search_module_default()).search,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                id: "search-box",
                className: external_classnames_default()((Search_module_default()).search_input, !openSearchBox ? (Search_module_default()).hide_box : (Search_module_default()).show_box),
                type: "text",
                placeholder: "Search..."
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                htmlFor: "search-box",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(BiSearch_namespaceObject.BiSearch, {
                        onClick: ()=>setOpenSearchBox(true),
                        className: external_classnames_default()((Search_module_default()).search_icon, openSearchBox ? (Search_module_default()).remove_icon : (Search_module_default()).add_icon)
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(IoClose_namespaceObject.IoClose, {
                        onClick: ()=>setOpenSearchBox(false),
                        className: external_classnames_default()((Search_module_default()).search_icon, (Search_module_default()).last, !openSearchBox ? (Search_module_default()).remove_icon : (Search_module_default()).add_icon)
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Search_Search = (Search);

// EXTERNAL MODULE: external "react-pro-sidebar"
var external_react_pro_sidebar_ = __webpack_require__(1981);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/layout/Sidebar/Sidebar.module.scss
var Sidebar_module = __webpack_require__(1323);
var Sidebar_module_default = /*#__PURE__*/__webpack_require__.n(Sidebar_module);
;// CONCATENATED MODULE: ./components/layout/Sidebar/Item.js





const Item = ({ href ="#" , name  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: href,
        className: external_classnames_default()((Sidebar_module_default()).item),
        children: name
    });
};
/* harmony default export */ const Sidebar_Item = (Item);

// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
;// CONCATENATED MODULE: ./components/layout/Sidebar/SubItem.js





const SubItem = ({ children , name  })=>{
    const [openItems, setOpenItems] = external_react_default().useState(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()((Sidebar_module_default()).sub_item),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                onClick: ()=>setOpenItems(!openItems),
                className: (Sidebar_module_default()).dropdown,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        children: [
                            name,
                            " "
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(icons_.CaretDownOutlined, {
                        className: external_classnames_default()((Sidebar_module_default()).dropdown_icon, openItems ? (Sidebar_module_default()).open : "")
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: external_classnames_default()((Sidebar_module_default()).dropdown_item, openItems ? (Sidebar_module_default()).dropdown_item_open : ""),
                children: children
            })
        ]
    });
};
/* harmony default export */ const Sidebar_SubItem = (SubItem);

;// CONCATENATED MODULE: ./components/layout/Sidebar/Sidebar.js






const Sidebar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()((Sidebar_module_default()).sidebar),
        style: {
            top: "70px"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Item, {
                href: "/product-categories",
                name: "Products"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Sidebar_SubItem, {
                name: "Biochemical",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Item, {
                        href: "/",
                        name: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Item, {
                        href: "/about",
                        name: "About"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Item, {
                        href: "/client",
                        name: "Clients"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Item, {
                href: "/contact",
                name: "Contact"
            })
        ]
    });
};
/* harmony default export */ const Sidebar_Sidebar = (Sidebar);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/layout/Header/Header.js













const Header = ()=>{
    const [isMenuOpen, setIsMenuOpen] = (0,external_react_.useState)(false);
    const [menuImage, setMenuImage] = (0,external_react_.useState)();
    const dropdownOverlay = (0,external_react_.useRef)();
    const { collapseSidebar  } = (0,external_react_pro_sidebar_.useProSidebar)();
    let router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        handleMenuImage(router.pathname);
        dropdownOverlay.current.style.transform = isMenuOpen ? "scale(1)" : "scale(0)";
    }, [
        isMenuOpen
    ]);
    function handleMenuImage(pathname) {
        if (pathname === "/") {
            setMenuImage("/assets/imgs/menu-1.jpg");
        } else if (pathname === "/about") {
            setMenuImage("/assets/imgs/menu-2.jpg");
        } else if (pathname === "/clients") {
            setMenuImage("/assets/imgs/menu-3.jpg");
        }
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
            className: external_classnames_default()((Header_module_default()).navbar),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: external_classnames_default()("tablet:w-8/12 w-11/12 hidden desktop:block mx-auto h-full"),
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: external_classnames_default()("flex flex-wrap items-center justify-between h-full"),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: external_classnames_default()("flex items-center"),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/",
                                    className: external_classnames_default()("flex items-center"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_h/* default */.Z,
                                        alt: "Biochemical logo",
                                        className: external_classnames_default()("w-36")
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: external_classnames_default()("h-full flex items-center"),
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: external_classnames_default()("h-full flex  items-center justify-between uppercase font-semibold text-base space-x-16"),
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: external_classnames_default()("mr-4 h-full flex items-center"),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/product-categories",
                                                className: external_classnames_default()("text-gray-600"),
                                                children: "Products"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            onMouseOver: ()=>setIsMenuOpen(true),
                                            onMouseLeave: ()=>setIsMenuOpen(false),
                                            className: external_classnames_default()((Header_module_default()).dropdown, "mr-4 h-full flex items-center"),
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                    href: "#",
                                                    className: external_classnames_default()("text-gray-600 flex items-center "),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "Biochemical"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(RiArrowDownSLine_namespaceObject.RiArrowDownSLine, {
                                                            className: external_classnames_default()((Header_module_default()).dropdown_icon, "ml-1 w-6 h-6")
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: external_classnames_default()("absolute container bg-white flex h-72 mx-auto rounded-b-xl shadow-2xl", (Header_module_default()).dropdown_item),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: external_classnames_default()("w-1/2  ml-28 mt-10 "),
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                className: external_classnames_default()("flex flex-col  gap-4 border-l-2 cursor-pointer "),
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                        onMouseOver: ()=>handleMenuImage("/"),
                                                                        className: external_classnames_default()("text-gray-600 hover:text-gray-700 text-gray-400 border-l-2 border-transparent -ml-0.5 hover:border-gray-700  p-2 pl-5"),
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                            className: "block",
                                                                            href: "/",
                                                                            children: "Home"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                        onMouseOver: ()=>handleMenuImage("/about"),
                                                                        className: external_classnames_default()("text-gray-600 hover:text-gray-700 text-gray-400 border-l-2 border-transparent -ml-0.5 hover:border-gray-700  p-2 pl-5"),
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                            className: "block",
                                                                            href: "/about",
                                                                            children: "About"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                        onMouseOver: ()=>handleMenuImage("/clients"),
                                                                        className: external_classnames_default()("text-gray-600 hover:text-gray-700 text-gray-400 border-l-2 border-transparent -ml-0.5 hover:border-gray-700  p-2 pl-5"),
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                            className: "block",
                                                                            href: "/client",
                                                                            children: "Clients"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: external_classnames_default()((Header_module_default()).right, "w-1/2 bg-cover-i bg-no-repeat bg-blue-500 rounded-br-xl transition-all ease-linear duration-100"),
                                                            style: {
                                                                background: `url(${menuImage})`
                                                            }
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: external_classnames_default()("mr-4 h-full flex items-center"),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/contact",
                                                className: external_classnames_default()("text-gray-600"),
                                                children: "Contact"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: external_classnames_default()((Header_module_default()).overlay),
                                ref: dropdownOverlay
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: external_classnames_default()("flex items-center"),
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: "tel:+8801711-000000",
                                        className: external_classnames_default()("flex items-center text-gray-400 mr-16"),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(FaPhoneSquareAlt_namespaceObject.FaPhoneSquareAlt, {
                                                className: external_classnames_default()("h-5 w-5 mr-2")
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "+8801711-000000"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "relative h-full",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "absolute right-0 -top-5 ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Search_Search, {})
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: external_classnames_default()("tablet:container px-4 block desktop:hidden mx-auto h-full"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Sidebar, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: external_classnames_default()("flex flex-wrap items-center justify-between h-full"),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: external_classnames_default()((Header_module_default()).hamburger),
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                        htmlFor: "check",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "checkbox",
                                                id: "check",
                                                onClick: ()=>collapseSidebar()
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: external_classnames_default()("flex items-center"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        className: external_classnames_default()("flex items-center"),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: logo_h/* default */.Z,
                                            alt: "Biochemical logo",
                                            className: external_classnames_default()("w-36")
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: external_classnames_default()("flex items-center"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: external_classnames_default()("flex items-center"),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "relative h-full",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "absolute right-0 -top-5 ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Search_Search, {})
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Header_Header = (Header);


/***/ }),

/***/ 1408:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Header_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(433);
/* harmony import */ var _Footer_Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2907);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Footer_Footer__WEBPACK_IMPORTED_MODULE_3__]);
_Footer_Footer__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header_Header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer_Footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1408);
/* harmony import */ var react_pro_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1981);
/* harmony import */ var react_pro_sidebar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(991);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css_free_mode__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9241);
/* harmony import */ var swiper_css_free_mode__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css_free_mode__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var swiper_css_thumbs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7383);
/* harmony import */ var swiper_css_thumbs__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(swiper_css_thumbs__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_3__, _services_store__WEBPACK_IMPORTED_MODULE_5__]);
([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_3__, _services_store__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// import "slick-carousel/slick/slick-theme.css";







function App({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_pro_sidebar__WEBPACK_IMPORTED_MODULE_4__.ProSidebarProvider, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_services_store__WEBPACK_IMPORTED_MODULE_5__/* .wrapper.withRedux */ .Y.withRedux(App));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5782:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ combinedReducer)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _siteDetails_siteDetailsSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1475);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_siteDetails_siteDetailsSlice__WEBPACK_IMPORTED_MODULE_1__]);
_siteDetails_siteDetailsSlice__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const combinedReducer = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.combineReducers)({
    siteDetails: _siteDetails_siteDetailsSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP
}); // export const masterReducer = (state, action) => {
 //   if (action.type === HYDRATE) {
 //     const nextState = {
 //       ...state,
 //       siteDetails: [...action.payload, ...state.payload]
 //     };
 //     return nextState;
 //   }
 //   return combinedReducer(state, action);
 // }

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1475:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports getSiteDetails, siteDetailsSlice, setNeedToUpdate, setSiteDetails, setSiteDetailsError, setSiteDetailsLoading */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_api_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2983);
/* harmony import */ var _utils_axiosInstance__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1840);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axiosInstance__WEBPACK_IMPORTED_MODULE_2__]);
_utils_axiosInstance__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getSiteDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("siteDetails/getSiteDetails", async ({ rejectWithValue  })=>{
    try {
        const response = await _utils_axiosInstance__WEBPACK_IMPORTED_MODULE_2__/* .axiosInstance.get */ .b.get(_utils_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .API.baseUrl */ .b.baseUrl + _utils_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .API.siteDetails.getDetails */ .b.siteDetails.getDetails);
        return response.data;
    } catch (error) {
        return rejectWithValue(error.response.data);
    }
});
const initialState = {
    data: [],
    isLoading: false,
    isSuccess: false,
    needToUpdate: true,
    isError: false,
    error: null
};
const siteDetailsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "siteDetails",
    initialState,
    reducers: {
        setNeedToUpdate: (state, action)=>{
            state.needToUpdate = action.payload;
        },
        setSiteDetails: (state, action)=>{
            state.data = action.payload;
            state.needToUpdate = false;
            state.isLoading = false;
            state.isSuccess = true;
            state.isError = false;
        },
        setSiteDetailsError: (state, action)=>{
            state.data = [];
            state.isLoading = false;
            state.needToUpdate = false;
            state.isSuccess = false;
            state.isError = true;
            state.error = action;
        },
        setSiteDetailsLoading: (state, action)=>{
            state.isLoading = action.payload;
            state.isSuccess = false;
            state.isError = false;
        }
    },
    extraReducers: {
        [getSiteDetails.pending]: (state)=>{
            state.isLoading = true;
        },
        [getSiteDetails.fulfilled]: (state, action)=>{
            state.data = action.payload;
            state.needToUpdate = false;
            state.isLoading = false;
            state.isSuccess = true;
            state.isError = false;
        },
        [getSiteDetails.rejected]: (state, action)=>{
            state.data = [];
            state.isLoading = false;
            state.needToUpdate = false;
            state.isSuccess = false;
            state.isError = true;
            state.error = action;
        }
    }
});
const { setNeedToUpdate , setSiteDetails , setSiteDetailsError , setSiteDetailsLoading  } = siteDetailsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (siteDetailsSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 991:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ wrapper)
/* harmony export */ });
/* unused harmony export makeStore */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5782);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reducers__WEBPACK_IMPORTED_MODULE_2__]);
_reducers__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const makeStore = ()=>(0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
        reducer: _reducers__WEBPACK_IMPORTED_MODULE_2__/* .combinedReducer */ .F
    });
const wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(makeStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ API)
/* harmony export */ });
const API = {
    baseUrl: "http://127.0.0.1:8000",
    accessToken: "1e3b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b",
    siteDetails: {
        getDetails: "/site-details/"
    }
};


/***/ }),

/***/ 1840:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ axiosInstance)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _api_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2983);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: _api_constant__WEBPACK_IMPORTED_MODULE_1__/* .API.baseUrl */ .b.baseUrl,
    timeout: 30000,
    headers: {
        "Authorization": "Token " + _api_constant__WEBPACK_IMPORTED_MODULE_1__/* .API.accessToken */ .b.accessToken
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 9241:
/***/ (() => {



/***/ }),

/***/ 9176:
/***/ (() => {



/***/ }),

/***/ 7383:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 7066:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 5648:
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 1981:
/***/ ((module) => {

"use strict";
module.exports = require("react-pro-sidebar");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664], () => (__webpack_exec__(8484)));
module.exports = __webpack_exports__;

})();