export const API = {
  baseUrl: "http://127.0.0.1:8000",
  accessToken: "1e3b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b1b",
  siteDetails: {
    getDetails: "/site-details/"
  }
}
