export const base_url = "http://127.0.0.1:8000/biochemical"
// export const base_url="/app/api";